package bank;

public class OperacaoBancaria extends Conta {

	
	
	void sacar() {
		
	}
	void depositar() {
		
	}
	void transferir() {
		
	}
}
