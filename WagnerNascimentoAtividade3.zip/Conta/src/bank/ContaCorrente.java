package bank;

public class ContaCorrente extends Conta {
	
	private double juros;

	public double getJuros() {
		return juros;
	}

	public void setJuros(double juros) {
		this.juros = juros;
	}
	
}
